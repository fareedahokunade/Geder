
import { StyleSheet } from 'react-native';

export const style = StyleSheet.create({
	headerInviteContainer: {
		marginLeft: 0,
		marginRight: 10
	},
	headerInvite: {
		backgroundColor: 'transparent',
		paddingHorizontal: 10
	}
});