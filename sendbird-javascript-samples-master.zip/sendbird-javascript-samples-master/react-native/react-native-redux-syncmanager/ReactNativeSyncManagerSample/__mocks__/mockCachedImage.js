jest.mock('react-native-cached-image', () => ({
  CachedImage: 'CachedImage'
}));
