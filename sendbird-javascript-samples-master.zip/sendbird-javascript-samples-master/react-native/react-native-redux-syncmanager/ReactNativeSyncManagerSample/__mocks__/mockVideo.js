jest.mock('react-native-video', () => {
  return 'Video';
});
